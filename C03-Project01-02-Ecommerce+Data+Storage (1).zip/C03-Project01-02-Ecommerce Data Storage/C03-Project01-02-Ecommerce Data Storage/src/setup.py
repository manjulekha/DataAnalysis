import csv
from venv import create
import database as db

PW = "sQld@taAnalytics"  # IMPORTANT! Put your MySQL Terminal password here.
ROOT = "root"
DB = "ecommerce_record"  # This is the name of the database we will create in the next step - call it whatever you like.
LOCALHOST = "localhost"  # considering you have installed MySQL server on your computer

RELATIVE_CONFIG_PATH = 'E:\\Data Science\\C03-Project01-02-Ecommerce Data Storage\\C03-Project01-02-Ecommerce Data Storage'

USER = 'users'
PRODUCTS = 'products'
ORDER = 'orders'

connection = db.create_server_connection(LOCALHOST, ROOT, PW)

# creating the schema in the DB
db.create_and_switch_database(connection, DB, DB)

# Create the tables through python code here
# if you have created the table in UI, then no need to define the table structure
create_users_table = """
    CREATE TABLE users (
        user_id varchar(10) PRIMARY KEY,
        user_email varchar(45) NOT NULL,
        user_name varchar(45) NOT NULL,
        user_password varchar(45) NOT NULL,
        user_address varchar(45) NOT NULL,
        is_vendor tinyint DEFAULT 0

    )
    """


create_products_table = """
    CREATE TABLE products (
        product_id varchar(50) NOT NULL PRIMARY KEY,
        product_name varchar(45) NOT NULL,
        product_description varchar(100) NOT NULL,
        vendor_id varchar(45) NOT NULL,
        product_price varchar(45) NOT NULL,
        emi_available varchar(10) NOT NULL
         CONSTRAINT `FK_vendor_id` FOREIGN KEY (vendor_id) REFERENCES users(user_id)


    )
    """


create_orders_table = """
    CREATE TABLE orders (
        order_id INT,
        total_value float(45) NOT NULL,
        customer_id varchar(45) NOT NULL,
        vendor_id varchar(45) NOT NULL,
        order_quantity Int NOT NULL,
        reward_point Int NOT NULL,
        CONSTRAINT `FK_vendor_id` FOREIGN KEY (vendor_id) REFERENCES users(user_id),
        CONSTRAINT `FK_customer_id` FOREIGN KEY (customer_id) REFERENCES users(user_id)

    )
    """

create_customer_leaderboards_table ="""
    CREATE TABLE customer_leaderboards (
		customer_id varchar(10) NOT NULL PRIMARY KEY,
        total_value float(45) NOT NULL,
        customer_name varchar(50) NOT NULL,
        customer_email varchar(50) NOT NULL,
        CONSTRAINT `FK_customer_id` FOREIGN KEY (customer_id) REFERENCES users(user_id)
	)
    """


# If you are using python to create the tables, call the relevant query to complete the creation
db.create_Insert_query(connection, create_users_table)
print("users table created")

db.create_Insert_query(connection, create_products_table)
print("products table created")

db.create_Insert_query(connection, create_orders_table)
print("orders table created")

db.create_Insert_query(connection, create_customer_leaderboards_table)
print("customer leaderboards table created")


print("Data Insertion is user table is initiated: ")
with open(RELATIVE_CONFIG_PATH + USER + '.csv', 'r') as f:
    val = []
    data = csv.reader(f)
    for row in data:
        val.append(tuple(row))

    Sql='''
    INSERT INTO users (user_id, user_name, user_email, user_password, user_address, is_vendor)
    VALUES (%s, %s, %s, %s, %s, %s)
    '''

    val.pop(0)
    db.insert_many_records(connection, Sql, val)

    """
    Here we have accessed the file data and saved into the val data struture, which list of tuples. 
    Now you should call appropriate method to perform the insert operation in the database. 
    """
print("Data Insertion is products table is initiated: ")
with open(RELATIVE_CONFIG_PATH + PRODUCTS + '.csv', 'r') as f:
    val = []
    data = csv.reader(f)
    for row in data:
        val.append(tuple(row))

    Sql='''
    INSERT INTO products (product_id, product_name, product_description, product_price, emi_available, vendor_id)
    VALUES (%s, %s, %s, %s, %s, %s)
    '''

    val.pop(0)
    db.insert_many_records(connection, Sql, val)
    
    """
    Here we have accessed the file data and saved into the val data struture, which list of tuples. 
    Now you should call appropriate method to perform the insert operation in the database. 
    """

print("Data Insertion is orders table is initiated: ")
with open(RELATIVE_CONFIG_PATH + orders + '.csv', 'r') as f:
    val = []
    data = csv.reader(f)
    for row in data:
        val.append(tuple(row))

    Sql='''
    INSERT INTO orders (order_id, total_value, order_quantity, reward_point, vendor_id, customer_id)
    VALUES (%s, %s, %s, %s, %s, %s)
    '''

    val.pop(0)
    db.insert_many_records(connection, Sql, val)
    
    """
    Here we have accessed the file data and saved into the val data struture, which list of tuples. 
    Now you should call appropriate method to perform the insert operation in the database. 
    """