class Products:

    def add_product(self, product_name, product_type, available_quantity, unit_price):
        pass

    def search_product_by_name(self, product_by_name):
        pass

    def get_all_products(self):
        pass
