class Vendor:

    def login(self, username, password):
        pass

    def logout(self):
        pass
