from Abstractions.Abstractions.Vendor import Vendor
from Models.VendorModel import VendorModel
from Models.VendorsessionModel import VendorsessionModel


class VendorImplementation:
    pass


class VendorImplementation (Vendor):
    def __init__(self) -> VendorImplementation:
        """

        :rtype: object
        """
        self.vendor_model = VendorModel()
        self.Vendor_session = VendorsessionModel()

    def login (self, username, password):
        if self.vendor_model.is_correct_vendor(username, password):
            self.vendor_session.login(username)
            print("user {} logged in successfully!".format(username))
            return True
        else:
            print("Invalid Username or password.")
            return False

    def logout (self, username):
        self.vendor_session.logout(username)
        print("user {} logged out successfully!".format(username))