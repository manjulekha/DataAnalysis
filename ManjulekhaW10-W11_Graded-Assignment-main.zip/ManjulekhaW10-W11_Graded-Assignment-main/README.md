# SupriyaNaik_W11_Graded-Assignment
Created Dockerfile in Ubuntu and tested prediction in the URL.
